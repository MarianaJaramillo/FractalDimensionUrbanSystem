import cv2
import numpy as np
import os
import matplotlib.pyplot as plt


def load_image(path, grayscale=True):
    """
    Loads an image from disk.

    Args:
        path (str): Path to the image file.
        grayscale (bool): If True, loads the image in grayscale.

    Returns:
        np.ndarray: Loaded image.
    """
    if grayscale:
        image = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    else:
        image = cv2.imread(path, cv2.IMREAD_COLOR)

    if image is None:
        raise FileNotFoundError(f"Could not load image: {path}")
    return image


def binarize_image(image, threshold=255, auto_invert=False):
    """
    Binarizes a grayscale image using a fixed threshold.

    Args:
        image (np.ndarray): Input grayscale image.
        threshold (int): Threshold value (0–255).
        auto_invert (bool): If True, inverts automatically if background is white.

    Returns:
        np.ndarray: Binary image (values 0 and 255).
    """
    _, binary = cv2.threshold(image, threshold, 255, cv2.THRESH_BINARY)

    if auto_invert:
        white_ratio = np.mean(binary == 255)
        if white_ratio > 0.5:
            binary = cv2.bitwise_not(binary)

    return binary


def save_image(image, path):
    """
    Saves an image to disk.

    Args:
        image (np.ndarray): Image to save.
        path (str): Destination file path.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    cv2.imwrite(path, image)


def show_image(window_name, image, scale=0.8):
    """
    Displays an image in a resizable OpenCV window.

    Args:
        window_name (str): Title of the window.
        image (np.ndarray): Image to display.
        scale (float): Resize factor for display.
    """
    resized = cv2.resize(image, (0, 0), fx=scale, fy=scale)
    cv2.imshow(window_name, resized)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def display_with_matplotlib(image, title="Image"):
    """
    Display image using matplotlib (useful in Jupyter or script).

    Args:
        image (np.ndarray): Image to display.
        title (str): Title of the plot.
    """
    plt.imshow(image, cmap='gray')
    plt.title(title)
    plt.axis('off')
    plt.tight_layout()
    plt.show()


# Ejemplo de uso
if __name__ == "__main__":
    input_path = "ruta/a/tu/imagen.png"
    output_path = "imagenes_binarizadas/imagen_binaria.png"

    # Cargar imagen
    img_gray = load_image(input_path)

    # Binarizar con detección automática de inversión
    img_bin = binarize_image(img_gray, threshold=128, auto_invert=True)

    # Guardar resultado
    save_image(img_bin, output_path)

    # Mostrar resultado con matplotlib
    display_with_matplotlib(img_bin, title="Imagen Binarizada")
