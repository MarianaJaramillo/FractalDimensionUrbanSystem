import numpy as np
import matplotlib.pyplot as plt
import time

class FractalDimensionCalculator:
    def __init__(self, binary_image):
        # Ensure image is binary (1s and 0s); white pixels contain information
        self.image = (binary_image > 0).astype(np.uint8)

    # Count the number of non-empty boxes at a given box size
    def box_count(self, box_size):
        h, w = self.image.shape
        count = 0
        for i in range(0, h, box_size):
            for j in range(0, w, box_size):
                box = self.image[i:i + box_size, j:j + box_size]
                if np.any(box):  # Count box if it contains at least one white pixel
                    count += 1
        return count

    # Compute the fractal dimension using the standard box-counting method
    def compute_fractal_dimension(self, min_box_size=4, max_box_size=None, max_points=8, plot=False):
        # Set maximum box size if not provided
        if max_box_size is None:
            max_box_size = min(self.image.shape) // 2

        # Use box sizes as powers of 2
        exponents = list(range(
            int(np.log2(min_box_size)),
            int(np.log2(max_box_size)) + 1
        ))
        # Use only the smallest 'max_points' scales for linear regression
        exponents = exponents[-max_points:]
        box_sizes = [2**i for i in exponents]

        sizes = []  # log(1 / box size)
        counts = []  # log(box count)

        start_time = time.time()
        # Count boxes for each box size
        for size in box_sizes:
            count = self.box_count(size)
            if count > 0:
                sizes.append(np.log(1.0 / size))
                counts.append(np.log(count))
        seq_time = time.time() - start_time

        # Ensure we have enough points for linear regression
        if len(sizes) < 2:
            raise ValueError("Not enough valid box sizes for linear regression.")

        # Perform linear regression on log-log values to estimate fractal dimension
        coeffs = np.polyfit(sizes, counts, 1)
        fractal_dimension = coeffs[0]

        # Optionally plot the regression
        if plot:
            plt.figure(figsize=(6, 4))
            plt.plot(sizes, counts, 'o-', label='Box counts')
            plt.plot(sizes, np.polyval(coeffs, sizes), '--', label=f'Fit: slope={fractal_dimension:.3f}')
            plt.xlabel("log(1 / box size)")
            plt.ylabel("log(box count)")
            plt.title("Fractal Dimension (Box-Counting)")
            plt.legend()
            plt.tight_layout()
            plt.show()

        return fractal_dimension, sizes, counts, seq_time
