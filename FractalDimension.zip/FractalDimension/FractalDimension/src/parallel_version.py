import numpy as np
import multiprocessing as mp
import matplotlib.pyplot as plt
import time

# Helper function to check if a given box contains any white pixels (non-zero)
def _is_non_empty_box(args):
    image, i, j, box_size = args
    box = image[i:i + box_size, j:j + box_size]
    return int(np.any(box))

class ParallelFractalDimensionCalculator:
    def __init__(self, binary_image):
        # Ensure binary format: white pixels (1) contain information, black pixels (0) are ignored
        self.image = (binary_image > 0).astype(np.uint8)

    # Count the number of non-empty boxes at a given box size using parallel processing
    def parallel_box_count(self, box_size, num_processes=None):
        h, w = self.image.shape

        # Generate all possible box coordinates
        tasks = [
            (self.image, i, j, box_size)
            for i in range(0, h, box_size)
            for j in range(0, w, box_size)
        ]

        # Use multiprocessing to count non-empty boxes
        with mp.Pool(processes=num_processes) as pool:
            results = pool.map(_is_non_empty_box, tasks)

        return sum(results)

    # Estimate fractal dimension using the box-counting method (log-log regression)
    def compute_fractal_dimension(self, min_box_size=4, max_box_size=None, max_points=8, plot=False, num_processes=None):
        if max_box_size is None:
            max_box_size = min(self.image.shape) // 2

        # Define box sizes as powers of 2
        exponents = list(range(
            int(np.log2(min_box_size)),
            int(np.log2(max_box_size)) + 1
        ))

        # Use only the last 'max_points' to ensure linearity at smaller scales
        exponents = exponents[-max_points:]
        box_sizes = [2**i for i in exponents]

        sizes = []
        counts = []

        start_time = time.time()
        # Perform box counting at each selected scale
        for size in box_sizes:
            count = self.parallel_box_count(size, num_processes=num_processes)
            if count > 0:
                sizes.append(np.log(1.0 / size))
                counts.append(np.log(count))
        parallel_time = time.time() - start_time

        if len(sizes) < 2:
            raise ValueError("Not enough valid box sizes for regression.")

        # Linear regression on log-log data
        coeffs = np.polyfit(sizes, counts, 1)
        fractal_dimension = coeffs[0]

        # Optionally plot the log-log relationship
        if plot:
            plt.figure(figsize=(6, 4))
            plt.plot(sizes, counts, 'o-', label='Box counts')
            plt.plot(sizes, np.polyval(coeffs, sizes), '--', label=f'Fit: slope={fractal_dimension:.3f}')
            plt.xlabel("log(1 / box size)")
            plt.ylabel("log(box count)")
            plt.title("Fractal Dimension (Parallel Box-Counting)")
            plt.legend()
            plt.tight_layout()
            plt.show()

        return fractal_dimension, sizes, counts, parallel_time
