import numpy as np
import matplotlib.pyplot as plt
from fractal_dimension import FractalDimensionCalculator
from parallel_version import FractalDimensionCalculatorParallel

# Generar una imagen binaria de ejemplo (por ejemplo, un conjunto de Mandelbrot)
def generate_test_image(size=512):
    x = np.linspace(-2, 1, size)
    y = np.linspace(-1.5, 1.5, size)
    c = x[:, np.newaxis] + 1j * y[np.newaxis, :]
    z = np.zeros_like(c)
    img = np.zeros((size, size))
    
    for i in range(100):
        z = z**2 + c
        img += (np.abs(z) < 2).astype(int)
    
    return (img > 0).astype(np.uint8) * 255

# Comparación
test_image = generate_test_image(512)

# Secuencial
calc_seq = FractalDimensionCalculator(test_image)
fd_seq, sizes, counts, time_seq = calc_seq.compute_fractal_dimension(plot=True)

# Paralelo
calc_par = FractalDimensionCalculatorParallel(test_image)
fd_par, sizes, counts, time_par = calc_par.compute_fractal_dimension(plot=True)

print(f"\nComparación de tiempos:")
print(f"Secuencial: {time_seq:.4f} segundos")
print(f"Paralelo:   {time_par:.4f} segundos")
print(f"Speedup:    {time_seq/time_par:.2f}x")
