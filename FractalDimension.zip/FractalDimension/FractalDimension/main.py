import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import sys

from src.fractal_dimension import FractalDimensionCalculator
from src.parallel_version import ParallelFractalDimensionCalculator

# Load image in grayscale and apply binary threshold
def load_image(path, threshold=128):
    img = Image.open(path).convert('L')  # Convert to grayscale
    binary_img = np.array(img) > threshold
    return binary_img.astype(np.uint8)

# Main function to run both sequential and parallel implementations
def main(image_path):
    binary_image = load_image(image_path)

    print("Running sequential version...")
    seq_calc = FractalDimensionCalculator(binary_image)
    fd_seq, _, _, time_seq = seq_calc.compute_fractal_dimension(plot=False)
    print(f"Sequential dimension: {fd_seq:.4f}, time: {time_seq:.4f} s")

    print("\nRunning parallel version...")
    par_calc = ParallelFractalDimensionCalculator(binary_image)
    fd_par, _, _, time_par = par_calc.compute_fractal_dimension(plot=False)
    print(f"Parallel dimension: {fd_par:.4f}, time: {time_par:.4f} s")

    print("\nComparison:")
    print(f"Speedup: {time_seq / time_par:.2f}x" if time_par > 0 else "Undefined (zero parallel time)")

# Entry point for command-line execution
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python main.py path_to_image")
    else:
        main(sys.argv[1])
